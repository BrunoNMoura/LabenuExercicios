# React Context - Template de Aula

Template no codesandbox <br>
https://codesandbox.io/s/template-context-i4kjw1
