import Header from "../../components/Header/Header";

function NotFoundPage(props) {
  return (
    <div>
      <Header />
      <h1>Ops! Essa página foi levada pela Equipe Rocket!</h1>
    </div>
  );
}

export default NotFoundPage;
