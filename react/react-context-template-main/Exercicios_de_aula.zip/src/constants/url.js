export const BASE_URL = "https://pokeapi.co/api/v2/pokemon";
