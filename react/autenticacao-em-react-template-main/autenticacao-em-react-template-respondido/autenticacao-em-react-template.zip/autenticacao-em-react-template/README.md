# Template prática guiada Autenticação no React:

Documentação Postman https://documenter.getpostman.com/view/9731983/U16eu7nT#intro

**Durante a prática guiada de hoje usaremos o mesmo template da aula de React e formulários.
**

Abra o exercício de ontem e rode `npm run start` na pasta raíz do template.

Caso você não tenha feito ou tenha problemas não corrigidos no template anterior, poderá usar o templte deste repositório, baixando e rodando `npm install` na pasta correspondente. Se preferir, pode fazer o exercício no CodeSandBox pelo link: https://codesandbox.io/s/template-autenticacao-em-react-d9e771
