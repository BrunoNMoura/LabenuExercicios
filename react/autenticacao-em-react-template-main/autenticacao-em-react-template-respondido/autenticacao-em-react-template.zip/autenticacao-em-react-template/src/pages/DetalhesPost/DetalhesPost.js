import React from 'react'

export default function DetalhesPost() {
  return (
    <div>DetalhesPost</div>
  )
}
