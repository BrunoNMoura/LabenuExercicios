import React from 'react'
import { FormPost, Input, TextArea } from './styled'
import useForms from '../../hooks/useForms'
import axios from 'axios'
import { BASE_URL } from '../../constants/BASE_URL'
import useProtectedPage from '../../hooks/useProtected'


export default function CriarPost() {
  // Use request data só será usado para requisicoes do tipo GET
  //consulta na API, se não for do tipo get, se for put e delete, nao 
  //vamos usar da maneira que ele está 
   
  useProtectedPage()

  // PEgando o token da pessoa 
  const token = localStorage.getItem("token")

  const headers = {
    headers:{
      Authorization:token 
    }
  }
  
  //1. Criar o post com o use form, passando como parametro useForms({title:"",body:""})
  const {form, onChange, limparCampos } = useForms({title:"",body:""})
 
  const enviarPost = (e) => {
    e.preventDefault()
    console.log("entrou")
    console.log(form)
    // Endereco `${BASE_URL}/posts` / Os dados que queremos inserir => form
    // headers => quem vai ser a pessoa que pode colocar no banco de dados => token
    axios.post(`${BASE_URL}/posts`,form,headers)
    .then((res)=>{
      console.log('Entrou no then')
      console.log(res.data)
      limparCampos()
      window.location.reload()
    })
    .catch((err)=>{
      console.log(err)
    })
    

  }

  return (
    <FormPost onSubmit={enviarPost}>
      <label htmlFor='tituloPost'>Título:</label>
      <Input placeholder='digite um título para o seu post'
        value = {form.title}
        name = "title"
        onChange ={onChange}
      />
      <label htmlFor='textoPost'>Texto:</label>
      <TextArea placeholder='crie um post!' 
        value={form.body}
        name='body'
        onChange={onChange}
      />
      <button>Enviar</button>
    </FormPost>
  )
}
