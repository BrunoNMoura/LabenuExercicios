

export const Auth_token = {headers:{Authorization:"bruno-moura-ozemela"}}
 
export const Bruno_Name = "bruno-moura-ozemela"