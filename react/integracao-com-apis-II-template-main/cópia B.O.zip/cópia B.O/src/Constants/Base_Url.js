

export const UrlBase = "https://us-central1-labenu-apis.cloudfunctions.net/labenusers/users"