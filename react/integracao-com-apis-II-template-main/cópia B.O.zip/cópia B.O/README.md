# Template da aula de Async/await

Link codesandbox: https://codesandbox.io/s/integracao-com-apis-ii-template-k42l8z
