

const par = Number(prompt("Insira um número par"))
const restoDadivisao = par % 2
console.log("O número digitado foi", par, ".", "Resto da divisão é", restoDadivisao)